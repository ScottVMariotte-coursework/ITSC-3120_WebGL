var fs_red =`
	precision mediump float;
	varying vec4 color;
	
	void main() {
		gl_FragColor =vec4(1,1,0,1);
	}
`;

