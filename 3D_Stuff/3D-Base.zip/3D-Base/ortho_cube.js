var canvas;
var gl;

var program;
var vertexShader, fragmentShader;
var compiled;

var tri_verts = [];

var mod;
var view;
var per;

var cam_view;
var cam_fix;

var ambiantColor, diffuseColor, reflectSpecular;
var lightPosition;
var reflectAmbiant, reflectDiffuse, reflectSpecular;
var color, ambiant, diffuse, specular;
var ambiantProduct;

// all initializations
window.onload = function init() {
    // get canvas handle
    canvas = document.getElementById( "gl-canvas" );

	// WebGL Initialization
    gl = WebGLUtils.setupWebGL(canvas, {preserveDrawingBuffer: true} );
	if ( !gl ) {
		alert( "WebGL isn't available" );
	}
	view_a = new ViewPort( 0, 0, canvas.width/2, canvas.height );
	gl.clearColor( 0.8, 0.8, 0.0, 1.0 );
	gl.clear( gl.COLOR_BUFFER_BIT );
	
	view_b = new ViewPort( canvas.width/2, 0, canvas.width/2, canvas.height );
	gl.clearColor( 0.8, 0.8, 0.0, 1.0 );
	gl.clear( gl.COLOR_BUFFER_BIT );

	// create shaders, compile and link program
	program = createShaders();
    gl.useProgram(program);

	// create the colored cube
	
	createColorCube();
    // buffers to hold cube vertices and its colors
    vBuffer = new Buffer(gl.ARRAY_BUFFER);
	
	vBuffer.bind();
	vBuffer.setData(tri_verts);
	
    // variables through which shader receives vertex and other attributes
	vPosition = gl.getAttribLocation(program, "vPosition");
	gl.vertexAttribPointer(vPosition, 3, gl.FLOAT, false, 0, 0 );
	gl.enableVertexAttribArray( vPosition );
	
	//vColor = gl.getAttribLocation(program, "vColor");
	//gl.vertexAttribPointer(vColor, 4, gl.FLOAT, false, 0, 0 );
	//gl.enableVertexAttribArray(vColor );
	
	mod = new Uniform(program, "M_mod", "mat4");
	view = new Uniform(program, "M_view", "mat4");
	per = new Uniform(program, "M_per", "mat4");
	
	l_a_v = vec4(.2,.2,.2,1);
	l_d_v = vec4(1,1,1,1);
	l_s_v = vec4(1,1,1,1);
	l_p_v = vec4(1,2,3,1)
	
	m_a_v = vec4(1,0,1,1);
	m_d_v = vec4(1,.8,0,1);
	m_s_v = vec4(1,.8,0,1);
	
	m_sh_v = 100;
	
	emission = vec4(0,.3,.3,1);
	
	ambiantProduct = mult(l_a_v,m_a_v);
	diffuseProduct = mult(l_d_v,m_d_v);
	specularProduct = mult(l_s_v,m_s_v);
	
	
	u_amb = new Uniform(program, "ambiantProduct", "vec4");
	u_diff = new Uniform(program, "diffuseProduct", "vec4");
	u_spec = new Uniform(program, "specularProduct", "vec4");
	u_pos = new Uniform(program, "lightPosition", "vec4");
	u_shin = new Uniform(program, "shininess", "float");
	u_normal = new Uniform(program, "vNormal", "vec4")
	
	u_amb.setData(ambiantProduct);
	u_diff.setData(diffuseProduct);
	u_spec.setData(specularProduct);
	
	u_pos.setData(l_p_v);
	u_shin.setData(m_sh_v);

	cam_fix = new Camera([1,1,1],90,1);
	cam_fix.lookAt([0,0,0]);
	cam_view = new Camera([0,0,1],90,1);
	
	
	gl.enable(gl.DEPTH_TEST);
    render();
}
//
//-----------------Use keys to switch rotations-------------------!!
//
	var ghost = vec2(0,0);
	var input = 0;
	var kXZ = [0,0];
	window.onkeydown = function(event){
		var c = event.code;
		if(c == "KeyW" || c == "KeyS"){
			if(c == "KeyW" && kXZ[1] != 1){
				kXZ[1] ++;
			}else if(kXZ[1] != -1 && c == "KeyS"){
				kXZ[1] --;
			}
		}else if(c == "KeyA" || c == "KeyD"){
			if(c == "KeyA" && kXZ[0] != 1){
				kXZ[0] ++;
			}else if(kXZ[0] != -1 && c == "KeyD"){
				kXZ[0] --;
			}
		}
	}
	
	window.onkeyup = function(event){
		var c = event.code;
		if(c == "KeyW" || c == "KeyS"){
			if(c == "KeyW" && kXZ[1] != -1){
				kXZ[1] --;
			}else if(kXZ[1] != 1 && c == "KeyS"){
				kXZ[1] ++;
			}
		}else if(c == "KeyA" || c == "KeyD"){
			if(c == "KeyA" && kXZ[0] != -1){
				kXZ[0] --;
			}else if(kXZ[0] != 1 && c == "KeyD"){
				kXZ[0] ++;
			}
		}
	}
	
	window.onmousedown = function(event){
		input = 1;
	};
	window.onmouseup = function(){
		input = 0
	};
	
	window.onmousemove = function(event){
		if(input){
			rX = event.x - ghost[0];
			rY = event.y - ghost[1];
			cam_view.rotate_fps(-rY,rX);
		}
		ghost = vec2(event.x,event.y);
	};

// all drawing is performed here
function render(){
	view_b.set();
	gl.clear( gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);

	cam_view.move_fps([kXZ[0]*-.02,0,kXZ[1]*.02]);
	

	mod.setData(identity4());
	view.setData(cam_view.getMatrix());
	per.setData(cam_view.getPerspective_proj());
	gl.drawArrays(gl.TRIANGLES, 0, tri_verts.length );
	view_a.set();
	
	view.setData(cam_fix.getMatrix());
	per.setData(cam_fix.getPerspective_proj());
	gl.drawArrays(gl.TRIANGLES, 0, tri_verts.length );
	
// Create additional smaller cubes around the central cube. Simply scale
// half size and put them around the original cube. Each will have its own
// transformation and you will draw them separately after the main cube.
// This will help distinguish the views. Make sure the cubes do not result in a // symmetric view - then there is no point to having them!
	
	
	setTimeout(
        function (){requestAnimFrame(render);}, 10
    );
}


// create a colored cube with 8 vertices and colors at
// at each vertex
function createColorCube () {
	createQuad( 1, 0, 3, 2 );
	createQuad( 2, 3, 7, 6 );
	createQuad( 3, 0, 4, 7 );
	createQuad( 6, 5, 1, 2 );
	createQuad( 4, 5, 6, 7 );
	createQuad( 5, 4, 0, 1 );
}


function getCubeVertices() {
	return [
        [ -0.25, -0.25,  0.25 ],
        [ -0.25,  0.25,  0.25 ],
        [  0.25,  0.25,  0.25 ],
        [  0.25, -0.25,  0.25 ],
        [ -0.25, -0.25,  -0.25 ],
        [ -0.25,  0.25,  -0.25 ],
        [  0.25,  0.25,  -0.25 ],
        [  0.25, -0.25,  -0.25 ]
    ];
}
function getCubeVertexColors() {
	return [
        [ 0.0, 0.0, 0.0, 1.0 ],  // black
        [ 1.0, 0.0, 0.0, 1.0 ],  // red
        [ 1.0, 1.0, 0.0, 1.0 ],  // yellow
        [ 0.0, 1.0, 0.0, 1.0 ],  // green
        [ 0.0, 0.0, 1.0, 1.0 ],  // blue
        [ 1.0, 0.0, 1.0, 1.0 ],  // magenta
        [ 1.0, 1.0, 1.0, 1.0 ],  // white
        [ 0.0, 1.0, 1.0, 1.0 ]   // cyan
    ];
}

function createTri (i) {
	var vertices  = dolphins_data.vertices;
	return [vec3(vertices[i[0]]), vec3(vertices[i[1]]), vec3(vertices[i[2]])]
}

function createQuad (a, b, c, d) {
	var vertices  = getCubeVertices();
	//var vertex_colors  = getCubeVertexColors();

	// Each quad is rendered as two triangles as WebGL cannot
	// directly render a quad

	var indices = [ a, b, c, a, c, d ];

	for ( var i = 0; i < indices.length; ++i ) {
		tri_verts.push(vertices[indices[i]]);
		//tri_colors.push(vertex_colors[indices[i]]);
	}
}

// function that does all shader initializations and 
// returns the compiled shader program
function createShaders () {
    			// Create program object
    program = gl.createProgram();

    			//  Load vertex shader
    vertexShader = gl.createShader(gl.VERTEX_SHADER);
    gl.shaderSource(vertexShader, myVertexShader);
    gl.compileShader(vertexShader);
    gl.attachShader(program, vertexShader);
    compiled = gl.getShaderParameter(vertexShader, gl.COMPILE_STATUS);
    if (!compiled) {
      console.error(gl.getShaderInfoLog(vertexShader));
    }

    			//  Load fragment shader
    fragmentShader = gl.createShader(gl.FRAGMENT_SHADER);
    gl.shaderSource(fragmentShader, myFragmentShader);
    gl.compileShader(fragmentShader);
    gl.attachShader(program, fragmentShader);
    compiled = gl.getShaderParameter(fragmentShader, gl.COMPILE_STATUS);
    if (!compiled) {
      console.error(gl.getShaderInfoLog(fragmentShader));
    }

    			//  Link program
    gl.linkProgram(program);
    var linked = gl.getProgramParameter(program, gl.LINK_STATUS);
    if (!linked) {
      console.error(gl.getProgramInfoLog(program));
    }
	return program;
}

function identity4() {
    var m = [];
    m = [
            [1.0, 0.0, 0.0, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0],
        ];

    return m;
}

function transpose4x4(m) {
    var result = [];

    result.push ([m[0][0], m[1][0], m[2][0], m[3][0]]);
    result.push ([m[0][1], m[1][1], m[2][1], m[3][1]]);
    result.push ([m[0][2], m[1][2], m[2][2], m[3][2]]);
    result.push ([m[0][3], m[1][3], m[2][3], m[3][3]]);

    return result;
}
