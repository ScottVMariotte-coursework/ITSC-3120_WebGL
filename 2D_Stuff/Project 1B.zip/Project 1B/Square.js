
var gl;

var delay = 100;

var wY_max = 10;
var wX_max = 10;
var wY_min = -10;
var wX_min = -10;

var points;
var lines;
var triangles;

var program;
var pBuffer;
var lBuffer;
var tBuffer;

var vPosition;

var minMax;

var drawState = 2;
var inputType = 0;



window.onload = function init() {

    var canvas = document.getElementById( "gl-canvas" );
    
    gl = WebGLUtils.setupWebGL( canvas );
    if ( !gl ) { alert( "WebGL isn't available" ); }

    //
    //  Configure WebGL
    //
    gl.viewport( 0, 0, canvas.width, canvas.height );
    gl.clearColor( 0.5, 0.5, 0.5, 1.0 );

    //  Load shaders and initialize attribute buffers
    
    program = initShaders( gl, "vertex-shader", "fragment-shader" );
    gl.useProgram( program );
	
	minMax = gl.getUniformLocation( program, "minMax");
	gl.uniform2f(minMax, wX_max,wY_max);
	
    points = [];
	lines = [];
	triangles = [];
	
	pBuffer = gl.createBuffer();
	lBuffer = gl.createBuffer();
	tBuffer = gl.createBuffer();
	vPosition = gl.getAttribLocation( program, "vPosition");
	
	var input = 0;
	
	window.onmousedown = function(event){
		input = 1;
		var ndc = deviceToNdc(canvas,[event.x,event.y]);
		var w_ndc = ndcToWorld(canvas,ndc);
		var arr = [];
		
		if(event.x <= canvas.width & event.y <= canvas.height & inputType == 0){
			if(drawState == 0){
				gl.bindBuffer(gl.ARRAY_BUFFER,tBuffer);
				triangles.push(vec2(w_ndc[0],w_ndc[1]));
				arr = triangles;
				
			}else if(drawState == 1){
				gl.bindBuffer(gl.ARRAY_BUFFER,lBuffer);
				lines.push(vec2(w_ndc[0],w_ndc[1]));
				arr = lines;
				
			}else if(drawState == 2){
				gl.bindBuffer(gl.ARRAY_BUFFER,pBuffer);
				points.push(vec2(w_ndc[0],w_ndc[1]));
				arr = points;
			}
			
			gl.bufferData(gl.ARRAY_BUFFER,flatten(arr),gl.STATIC_DRAW);
			
		}else if(inputType == 1){	
			var trianlge = inTriangle(canvas,[event.x,event.y],triangles);
			var point = findPoint(canvas,[event.x,event.y],points);
			var line;
			console.log(point);
			console.log(trianlge);
			if(point != -1){
				document.getElementById("coord").innerHTML = 
				"index : " + point + 
				"	x : " + points[point][0] + 
				"	y : " + points[point][1];
			}else if(0){
				
			}else if(trianlge != -1){
				document.getElementById("coord").innerHTML = 
				"Trianlge : " + ((trianlge + 3) /3);
			}
		}
		
	};
	window.onmouseup = function(){
		input = 0
	};
	
	window.onmousemove = function(event){
		if(input == 1 & inputType != 1){
			
			var ndc = deviceToNdc(canvas,[event.x,event.y]);
			var w_ndc = ndcToWorld(canvas,ndc);
			
			document.getElementById("coord").innerHTML = 
			"Device (Mouse) Coords : " + event.x + " " + event.y + 
			"\nWorld Coords (Device-->World) : " + w_ndc[0] + " " + w_ndc[1] +
			"\nNDC (World-->NDC) : " + ndc[0] + " " + ndc[1];
		}
	};
	
    render();
}

//
//	Rendering
//

function render() {
    gl.clear( gl.COLOR_BUFFER_BIT );

    draw(gl.POINTS,pBuffer,points.length);
	draw(gl.LINES,lBuffer,lines.length);
	draw(gl.TRIANGLES,tBuffer,triangles.length);
	
    setTimeout(
        function (){requestAnimFrame(render);}, delay
    );
}

function draw(type,buff,n){
	gl.bindBuffer(gl.ARRAY_BUFFER,buff);
	gl.vertexAttribPointer(vPosition, 2, gl.FLOAT, false, 0, 0);
    gl.enableVertexAttribArray(vPosition);
	gl.drawArrays(type, 0,n);
}

//
//

function ndcToWorld(canvas,ndc){
	var w_ndc_x = wX_max * (ndc[0]);
	var w_ndc_y = wY_min * (ndc[1]);
	return [w_ndc_x, w_ndc_y]
}

function deviceToNdc(canvas,xy){
	ndc_x = -1.0 + 2.0 * xy[0]/canvas.width;
	ndc_y =   1.0 - 2.0 * xy[1]/canvas.height;
	return [ndc_x,ndc_y]
}

function inTriangle(canvas,xy,arr){
	xy = deviceToNdc(canvas, [xy[0],xy[1]]);
	xy = ndcToWorld(canvas, [xy[0], xy[1]]);
	
	var inside = false;
	for(var i =0; i < Math.floor(arr.length / 3) * 3; i += 3){
		var a = Math.abs(calcAreaTriangle(arr[i],arr[i+1],arr[i+2]));
		var a_sub = 0;
		for(var c = i; c < i+3; c ++){
			a_sub += Math.abs(calcAreaTriangle(xy,arr[(c%3) + i],arr[(((c%3) + 1)%3)+i]));
		}
		if(a_sub == a){
			return i;
		}
	}
	return -1;
}

function calcAreaTriangle(pA,pB,pC){
	return ((pA[0]*(pB[1]-pC[1])) + 
				(pB[0]*(pC[1]-pA[1])) + 
				(pC[0]*(pA[1]-pB[1]))) /
				2;
}

function findPoint(canvas,xy,arr){
	xy = deviceToNdc(canvas, [xy[0],xy[1]]);
	xy = ndcToWorld(canvas, [xy[0], xy[1]]);
	
	var index = -1;
	var d = 999999999999;
	for(var i =0; i < arr.length; i ++){
		var sub_d = Math.sqrt(Math.pow((xy[0] - arr[i][0]),2) + Math.pow((xy[1] - arr[i][1]),2));
		console.log(sub_d);
		if(sub_d < d){
			d = sub_d;
			index = i;
		}
	}
	if(d < .5){
		return index;
	}else{
		return -1;
	}
		
}

function submit(){
	xX = [parseInt(document.getElementById("Xmin").value),parseInt(document.getElementById("Xmax").value)];
	yY = [parseInt(document.getElementById("Ymin").value),parseInt(document.getElementById("Ymax").value)];
	
	gl.bindBuffer(gl.ARRAY_BUFFER,pBuffer);
	points = mapBuffs(xX,yY,points);
	
	gl.bindBuffer(gl.ARRAY_BUFFER,lBuffer);
	lines = mapBuffs(xX,yY,lines);
	
	gl.bindBuffer(gl.ARRAY_BUFFER,tBuffer);
	triangles = mapBuffs(xX,yY,triangles);
	
	wX_min = xX[0];
	wX_max = xX[1];
	
	wY_min = yY[0];
	wY_max = yY[1];
	
	gl.uniform2f(minMax, wX_max,wY_max);
}

function mapBuffs(xX,yY,verts){
	for (var i = 0; i < verts.length; i ++){
		verts[i] = vec2(verts[i][0] / wX_max * xX[1], verts[i][1] / wY_min * yY[0]);
	}
	gl.bufferData(gl.ARRAY_BUFFER,flatten(verts),gl.STATIC_DRAW);
	return verts;
}

function find(){
	inputType = 1;
}

function change(){
	inputType = 0;
}

function clearBuff(){
	points = [];
	lines = [];
	triangles = [];
	
	gl.bufferData(gl.ARRAY_BUFFER, flatten(points), gl.STATIC_DRAW);
}

function triangle(){
	drawState = 0;
}

function line(){
	drawState = 1;
}

function point(){
	drawState = 2;
}
